# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.apps import AppConfig


class Djangoapp2AppConfig(AppConfig):
    name = 'DjangoApp2_app'
